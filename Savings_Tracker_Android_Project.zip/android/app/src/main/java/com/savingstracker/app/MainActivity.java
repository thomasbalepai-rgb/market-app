package com.savingstracker.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
