/* Stand-in for the Claude-hosted database. Stores everything on THIS device (localStorage).
   To share data between officers, replace this file with a backend that implements the same
   small API (collection().onSnapshot, doc().set/update/delete/onSnapshot), e.g. Firebase Firestore. */
(function () {
  var KEY = 'savings-tracker-db-v1', store = {}, subs = [];
  try { store = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) { store = {}; }
  function persist() { try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) { throw { code: 'quota_exceeded' }; } }
  function snap(c) {
    var docs = Object.keys(store).filter(function (k) { return k.indexOf(c + '/') === 0 && k.split('/').length === 2; }).map(function (k) { var v = store[k]; return { id: k.split('/')[1], exists: true, data: function () { return JSON.parse(JSON.stringify(v)); } }; });
    return { docs: docs, size: docs.length };
  }
  function fire() { subs.forEach(function (f) { f(); }); }
  function on(f) { subs.push(f); setTimeout(f, 0); return function () { subs = subs.filter(function (x) { return x !== f; }); }; }
  var db = {
    collection: function (c) { return { onSnapshot: function (cb) { return on(function () { cb(snap(c)); }); } }; },
    doc: function (p) {
      return {
        onSnapshot: function (cb) { return on(function () { var v = store[p]; cb({ exists: !!v, data: function () { return v ? JSON.parse(JSON.stringify(v)) : undefined; } }); }); },
        set: async function (d) { store[p] = JSON.parse(JSON.stringify(d)); persist(); fire(); },
        update: async function (d) { store[p] = Object.assign({}, store[p] || {}, JSON.parse(JSON.stringify(d))); persist(); fire(); },
        delete: async function () { delete store[p]; persist(); fire(); }
      };
    }
  };
  var user = { can: async function () { return true; }, canEdit: async function () { return true; }, isOwner: function () { return true; } };
  var downloads = { save: async function (r) {
    var a = document.createElement('a'), b = new Blob([r.data], { type: 'text/csv' });
    a.href = URL.createObjectURL(b); a.download = r.filename; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000); return { status: 'saved' };
  } };
  if (!window.claude) window.claude = { use: async function (n) { return n === 'db' ? db : n === 'user' ? user : n === 'downloads' ? downloads : null; } };
})();
