# Savings Tracker – Android app project

This is a complete Android project (Capacitor) wrapping the tracker. You do not need Android Studio:
GitHub builds the installable app (APK) for you in about 5 minutes.

## Get the APK (no coding)
1. Create a free account at github.com and a **new private repository**.
2. Upload the *contents of this folder* (drag the files in, including the hidden `.github` folder), then commit.
3. Open the repository → **Actions** → **Build Android app** → wait for the green tick (or click **Run workflow**).
4. Open the finished run → **Artifacts** → download **SavingsTracker-apk** → unzip → `app-debug.apk`.
5. Send the APK to the phone (WhatsApp/Drive/USB), tap it, allow "install unknown apps", install.

## Publish on Google Play
The run also produces `SavingsTracker-play-bundle-unsigned` (an .aab). Play needs a **signed** bundle:
1. Create a Google Play developer account (one-time fee). New personal accounts must run a closed test first.
2. Sign the bundle: use Play App Signing – upload the .aab in Play Console and follow "App signing", or sign locally with
   `keytool -genkey -v -keystore release.jks -alias savings -keyalg RSA -keysize 2048 -validity 10000`
   then `jarsigner -keystore release.jks app-release.aab savings`. **Keep the keystore safe; losing it blocks updates.**
3. Change the app id in `capacitor.config.json` (`appId`) to your own unique id before first upload; it can never change later.
4. Add a privacy policy URL, screenshots and the Data safety form (the app handles customer names and mobile numbers).

## Important
- Data is stored **on the phone only** and is not shared between officers. For one shared live database, replace
  `www/local-backend.js` with a backend that supports the same few calls (Firebase Firestore with sign-in and access rules).
- The debug APK is for testing and internal use. Have the bank's compliance team approve hosting, consent wording,
  retention and device security before real customers are recorded. A lost unlocked phone exposes its data.
- Change the tracker code in `www/index.html`, then commit; GitHub rebuilds the APK.
